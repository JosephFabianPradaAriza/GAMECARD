/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LOGICA;

import java.util.ArrayList;
import java.util.Random;
import javax.swing.ImageIcon;

/**
 *
 * @author Joseph F
 */
public class Baraja {
    
    private Cartas[] cartas;
    private int CartasBaraja;
    
    public Baraja(){
        cartas = new Cartas[108];
    }
    
    public void reiniciar(){
        Cartas.Color[] colores = Cartas.Color.values();
        CartasBaraja = 0;
        
        for (int i = 0; i< colores.length-1; i++){
            Cartas.Color color = colores[i];
            cartas[CartasBaraja++] = new Cartas(color, Cartas.Valor.getValor(0));
            
            for(int j = 0; j < 10; j++){
                cartas[CartasBaraja++] = new Cartas(color, Cartas.Valor.getValor(j));
                cartas[CartasBaraja++] = new Cartas(color, Cartas.Valor.getValor(j));
            }
            
            Cartas.Valor[] valores = new Cartas.Valor[]{Cartas.Valor.Draw_Dos, Cartas.Valor.Saltar, Cartas.Valor.Reversa};
            for(Cartas.Valor valor : valores){
                cartas[CartasBaraja++] = new Cartas(color, valor);
                cartas[CartasBaraja++] = new Cartas(color, valor);
            }
        }
            
            Cartas.Valor[] valores = new Cartas.Valor[]{Cartas.Valor.Draw_Dos, Cartas.Valor.Saltar, Cartas.Valor.Reversa};
            for(Cartas.Valor valor : valores){
                for(int i = 0; i < 2; i++){
                    cartas[CartasBaraja++] = new Cartas(Cartas.Color.Morado, valor);
                }
            }
    }
    
        public void ReemplazarBaraja(ArrayList<Cartas> cartas){
            this.cartas = cartas.toArray(new Cartas[cartas.size()]);
            this.CartasBaraja = this.cartas.length;
        }
        
        public boolean EstaVacio(){
            return CartasBaraja == 0;
        }
        
        public void Mezclar(){
            int n = cartas.length;
            Random random = new Random();
            
            for(int i = 0; i < cartas.length; i ++){
                int ValorAleatorio = i + random.nextInt(n-1);
                Cartas CartaAleatoria = cartas[ValorAleatorio];
                cartas[ValorAleatorio] = cartas[i];
                cartas[i] = CartaAleatoria;
            }
        }
        
        public Cartas drawCard() throws IllegalArgumentException{
            if(EstaVacio()){
                throw new IllegalArgumentException("No se pueden robar cartas, puesto que no existen cartas en la baraja.");
            }
            return cartas[--CartasBaraja];
        }
        
        public ImageIcon drawCardImage() throws IllegalArgumentException{
            if(EstaVacio()){
                throw new IllegalArgumentException("No se puede robar una carta porque la baraja esta vacia.");
            }
            return new ImageIcon(cartas[--CartasBaraja].toString() + ".png");
        }
        
        public Cartas[] drawCard(int n){
            if (n < 0){
                throw new IllegalArgumentException("Deben de robarse cartas positivas, se intento adquirir" + n +" cartas.");
            }
            if (n > CartasBaraja){
                throw new IllegalArgumentException("No se pueden robar " + n + " cartas, solo hay " + CartasBaraja + " disponibles.");
            }
            
            Cartas[] ret = new Cartas[n];
            
            for(int i = 0; i < n; i++){
                ret[i] = cartas[--CartasBaraja];
            }
            return ret;
        }
        
}
