/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LOGICA;

import java.awt.Font;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author Joseph F
 */
public class Juego {
    private int JugadorActual;
    private String[] CodigoJugadores;
    
    private Baraja baraja;
    private ArrayList<ArrayList<Cartas>> ManoJugador;
    private  ArrayList<Cartas> Restantes;
    
    private Cartas.Color ColorValido;
    private Cartas.Valor ValorValido;
    
    boolean DireccionJuego;
    
    public Juego(String[] codigo_jugadores){
        baraja = new Baraja();
        baraja.Mezclar();
        Restantes = new ArrayList<Cartas>();
        
        CodigoJugadores = codigo_jugadores;
        JugadorActual = 0;
        DireccionJuego = false;

        ManoJugador = new ArrayList<ArrayList<Cartas>>();
        
        for(int i = 0; i < codigo_jugadores.length; i++){
            ArrayList<Cartas> mano = new ArrayList<Cartas>(Arrays.asList(baraja.drawCard(7)));
            ManoJugador.add(mano);
        }
    }
    
    public void iniciar(Juego juego){
        Cartas carta = baraja.drawCard();
        ColorValido = carta.getColor();
        ValorValido = carta.getValor();
        
        if(carta.getValor() == Cartas.Valor.Wild){
            iniciar(juego);
        }
        
        if(carta.getValor() == Cartas.Valor.Wild_Cuatro || carta.getValor() == Cartas.Valor.Draw_Dos){
            iniciar(juego);
        }
        
        if(carta.getValor() == Cartas.Valor.Saltar){
            JLabel message = new JLabel(CodigoJugadores[JugadorActual]+" a salido!");
            message.setFont(new Font("Arial", Font.BOLD, 48));
            JOptionPane.showMessageDialog(null, message);
            
            if(DireccionJuego == false){
                JugadorActual = (JugadorActual + 1) % CodigoJugadores.length;
            }
            
            else if(DireccionJuego == true){
                JugadorActual = (JugadorActual - 1) % CodigoJugadores.length;
                if(JugadorActual == -1){
                    JugadorActual = CodigoJugadores.length - 1;
                }
            }
        }
        
        if(carta.getValor() == Cartas.Valor.Reversa){
            JLabel message = new JLabel(CodigoJugadores[JugadorActual]+" La direccion del juego a cambiado!!");
            message.setFont(new Font("Arial", Font.BOLD, 48));
            JOptionPane.showMessageDialog(null, message);
            DireccionJuego ^= true;
            JugadorActual = CodigoJugadores.length - 1;
        }
        Restantes.add(carta);
    }
        
        
        public Cartas ObtenerCartaSuperior(){
            return new Cartas(ColorValido, ValorValido);
        }
        
        public ImageIcon ObtenerImagenCartaSuperior(){
            return new ImageIcon(ColorValido + "-" + ValorValido + ".png");
        }
        
        public boolean isGameOver(){
            for(String jugador : this.CodigoJugadores){
                if(TieneManoVacia(jugador)){
                    return true;
                }
            }
            return false;
        }
        
        public String ObtenerJugadorActual(){
            return this.CodigoJugadores[this.JugadorActual];
        }
        
        public String ObtenerJugadorPrevio(int i){
            int index = this.JugadorActual - i;
            if(index == -1){
                index = CodigoJugadores.length - 1;
            }
            return this.CodigoJugadores[index];
        }
        
        public String[] ObtenerJugadores(){
            return CodigoJugadores;
        }
        
        public ArrayList<Cartas> ObtenerManoJugador(String codigo_jugadores){
            int index = Arrays.asList(CodigoJugadores).indexOf(codigo_jugadores);
            return ManoJugador.get(index);
        }
        
        public Cartas ObtenerCartaJugador(String codigo_jugadores, int escoger){
            ArrayList<Cartas> mano = ObtenerManoJugador(codigo_jugadores);
            return mano.get(escoger);
        }
        
        public boolean TieneManoVacia(String codigo_jugadores){
            return ObtenerManoJugador(codigo_jugadores).isEmpty();
        }
        
        public boolean CartaValida(Cartas carta){
            return carta.getColor() == ColorValido || carta.getValor() == ValorValido;
        }
        
        public void TurnoJugador(String codigo_jugadores) throws ExcepcionTurnoInvalidoJugador{
            if(this.CodigoJugadores[this.JugadorActual] != codigo_jugadores){
                throw new ExcepcionTurnoInvalidoJugador("No es el turno de " + codigo_jugadores + ".", codigo_jugadores);
            }
        }
        
        public void submitDraws(String codigo_jugadores) throws ExcepcionTurnoInvalidoJugador{
            TurnoJugador(codigo_jugadores);
            
            if(baraja.EstaVacio()){
                baraja.ReemplazarBaraja(Restantes);
                baraja.Mezclar();
            }
            
            ObtenerManoJugador(codigo_jugadores).add(baraja.drawCard());
            if(DireccionJuego == false){
                JugadorActual = (JugadorActual + 1) % CodigoJugadores.length;
            }
            
            else if(DireccionJuego == true){
                JugadorActual = (JugadorActual - 1) % CodigoJugadores.length;
                if(JugadorActual == -1){
                    JugadorActual = CodigoJugadores.length - 1;
                }
            }
        }
        
        public void setColorCarta(Cartas.Color color){
            ColorValido = color;
        }
        
        public void EnviarCartaJugador(String codigo_jugadores, Cartas carta, Cartas.Color ColorDeclarado)
            throws ExcepcionTurnoInvalidoJugador, ExcepcionEnvioColorInvalido, ExcepcionEnvioValorInvalidoEnviado {
                TurnoJugador(codigo_jugadores);
                
                ArrayList<Cartas> Mano = ObtenerManoJugador(codigo_jugadores);
                
                if(!CartaValida(carta)){
                    if(carta.getColor() == Cartas.Color.Morado){
                        ColorValido = carta.getColor();
                        ValorValido = carta.getValor();
                    }
                    
                    if(carta.getColor() != ColorValido){
                        JLabel mensaje = new JLabel("Movimiento invalido, color esperado: "+ColorValido+" pero se obtuvo "+carta.getColor());
                        mensaje.setFont(new Font("Arial", Font.BOLD, 48));
                        String message = mensaje.getText();
                        JOptionPane.showMessageDialog(null, mensaje);
                        throw new ExcepcionEnvioColorInvalido(message, carta.getColor(), ColorValido);
                    }
                    
                    else if(carta.getValor() != ValorValido){
                        JLabel mensaje = new JLabel("Movimiento invalido, valor esperado: "+ValorValido+" pero se obtuvo "+carta.getValor());
                        mensaje.setFont(new Font("Arial", Font.BOLD, 48));
                        String message2 = mensaje.getText();
                        JOptionPane.showMessageDialog(null, mensaje);
                        throw new ExcepcionEnvioValorInvalidoEnviado(message2, carta.getValor(), ValorValido);
                    }
                }
                
                Mano.remove(carta);
                
                if(TieneManoVacia(this.CodigoJugadores[JugadorActual])){
                    JLabel mensaje = new JLabel(this.CodigoJugadores[JugadorActual] + " a ganado!");
                    mensaje.setFont(new Font("Arial", Font.BOLD, 48));
                    String message2 = mensaje.getText();
                    JOptionPane.showMessageDialog(null, mensaje);
                    System.exit(0);
                }
                
                ColorValido = carta.getColor();
                ValorValido = carta.getValor();
                Restantes.add(carta);
                
                if(DireccionJuego == false){
                    JugadorActual = (JugadorActual + 1) % CodigoJugadores.length;
                }
                else if(DireccionJuego == true){
                    JugadorActual = (JugadorActual - 1) % CodigoJugadores.length;
                    if (JugadorActual == -1){
                        JugadorActual    = CodigoJugadores.length - 1;
                    }
                }
                
                if (carta.getColor() == Cartas.Color.Morado){
                    ColorValido = ColorDeclarado;
                }
                
                if (carta.getValor() == Cartas.Valor.Draw_Dos){
                    codigo_jugadores = CodigoJugadores[JugadorActual];
                    ObtenerManoJugador(codigo_jugadores).add(baraja.drawCard());
                    ObtenerManoJugador(codigo_jugadores).add(baraja.drawCard());
                    JLabel mensaje = new JLabel(codigo_jugadores + " a tomado 2 cartas.");
                }
                
                if (carta.getValor() == Cartas.Valor.Wild_Cuatro){
                    codigo_jugadores = CodigoJugadores[JugadorActual];
                    ObtenerManoJugador(codigo_jugadores).add(baraja.drawCard());
                    ObtenerManoJugador(codigo_jugadores).add(baraja.drawCard());
                    ObtenerManoJugador(codigo_jugadores).add(baraja.drawCard());
                    ObtenerManoJugador(codigo_jugadores).add(baraja.drawCard());
                    JLabel mensaje = new JLabel(codigo_jugadores + " a tomado 4 cartas.");
                }
                
                if (carta.getValor() == Cartas.Valor.Saltar){
                    JLabel mensaje= new JLabel(CodigoJugadores[JugadorActual] + " a sido saltado!");
                    mensaje.setFont(new Font("Arial", Font.BOLD,48));
                    JOptionPane.showMessageDialog(null, mensaje);
                    if(DireccionJuego == false){
                        JugadorActual = (JugadorActual + 1) % CodigoJugadores.length;
                    }
                    
                    else if(DireccionJuego == true){
                        JugadorActual = (JugadorActual - 1) % CodigoJugadores.length;
                        if(JugadorActual == -1){
                            JugadorActual = CodigoJugadores.length - 1;
                        }
                    }
                }
                
                if (carta.getValor() == Cartas.Valor.Reversa){
                    JLabel mensaje= new JLabel(codigo_jugadores + " a sido saltado!");
                    mensaje.setFont(new Font("Arial", Font.BOLD,48));
                    JOptionPane.showMessageDialog(null, mensaje);
                    
                    DireccionJuego ^= true;
                    if (DireccionJuego == true){
                        JugadorActual = (JugadorActual - 2) % CodigoJugadores.length;
                        if (JugadorActual == -1){
                            JugadorActual = CodigoJugadores.length - 1;
                        }
                        
                        if (JugadorActual == -2){
                            JugadorActual = CodigoJugadores.length - 2;
                        }
                    }
                    else if (DireccionJuego == false){
                        JugadorActual = (JugadorActual + 2) % CodigoJugadores.length;
                    }
                }
        }
    }

class ExcepcionTurnoInvalidoJugador extends Exception{
    String CodigoJugadores;
    
    public ExcepcionTurnoInvalidoJugador(String message, String codigo_jugadores){
        super(message);
        CodigoJugadores = codigo_jugadores;
    }
    
    public String getCodigo_Jugadores(){
        return CodigoJugadores;
    }    
}

class ExcepcionEnvioColorInvalido extends Exception {
    private Cartas.Color esperado;
    private Cartas.Color actual;
    
    public ExcepcionEnvioColorInvalido(String mensaje, Cartas.Color actual, Cartas.Color esperado){
        this.esperado = esperado;
        this.actual = actual;
    }
}

class ExcepcionEnvioValorInvalidoEnviado extends Exception{
    private Cartas.Valor esperado;
    private Cartas.Valor actual;
    
    public ExcepcionEnvioValorInvalidoEnviado(String mensaje, Cartas.Valor actual, Cartas.Valor esperado){
        this.esperado = esperado;
        this.actual = actual;
    }
}   

